/*
 * Paint Launcher
 */
package paintapplication;


public class Main 
{
    public static PaintApplication paint; 
    
    public static void main(String[] args) 
    {
        paint = new PaintApplication();
    }
}
