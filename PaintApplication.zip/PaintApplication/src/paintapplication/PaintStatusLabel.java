/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package paintapplication;

public class PaintStatusLabel 
{
    String status; 
    
    public PaintStatusLabel(String string)
    {
        
    }
}
