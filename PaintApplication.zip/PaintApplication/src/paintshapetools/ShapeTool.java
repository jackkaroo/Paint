/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package paintshapetools;

import painttools.*;

import java.awt.*;

public abstract class ShapeTool extends AbstractTool
{
    public ShapeTool(Color clr, int dim)
    {
        super(clr, dim);
    }
}
