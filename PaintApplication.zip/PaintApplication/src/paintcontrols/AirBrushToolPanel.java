/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package paintcontrols;

import painttools.*;

public class AirBrushToolPanel extends PencilToolPanel
{
    public AirBrushToolPanel(Tool tool, int stroke)
    {
        super(tool, stroke);
    }
}
