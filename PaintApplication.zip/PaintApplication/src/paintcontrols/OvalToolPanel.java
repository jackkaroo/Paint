
package paintcontrols;

import painttools.*;

public class OvalToolPanel extends RectShapeToolPanel
{
    public OvalToolPanel(Tool tool, int stroke)
    {
        super(tool, stroke);
    }
}
